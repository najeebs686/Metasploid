# Metasploit-2
Second Edition Metasploit For Termux


 Hello Friends i am coming back with second my metasploit script...(work without Error..%)
 
 
               _______________________Bhai 4 You______________________
 
 ## Guide For installation....
 
 ## Follow my steps....
 
 
 
 0) first You Goto Your Home Directory after Installation...
                
                Just type :   cd $home
                
 1) git clone ( past url )
 
 2) cd Metasploit-2
 
 3) chmod 7777 install.sh
 
 4) chmod 7777 kingsploit.sh
 
 5) chmod 7777 bundle.s
 
 6) chmod +x README.md (any Problems to type (cat README.md))
 
 3) bash install.sh
 
 4) bash bundle.sh
 
 5) cd Metasploit-firmware
 
 6) ./msfconsole
 
 
 
 _______________________<visit : http://bhai4you.blogspot.com/  >________________________
 
 _______________________Script by Parixit Sutariya___________________________
 
